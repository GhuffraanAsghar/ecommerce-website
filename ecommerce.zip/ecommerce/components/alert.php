<?php
$alert_types = [
    'success_msg' => 'success',
    'warning_msg' => 'warning',
    'info_msg' => 'info',
    'error_msg' => 'error'
];

foreach ($alert_types as $msg_type => $alert_type) {
    if (isset($$msg_type)) {
        foreach ($$msg_type as $message) {
            echo '<script>swal("' . $message . '", "", "' . $alert_type . '");</script>';
        }
    }
}
?>
