<head>
        <script src="https://kit.fontawesome.com/05f313bbaf.js" crossorigin="anonymous"></script>
</head>

<div class="top-footer">
    <h2><i class="bx bx-envelope"></i> Sign Up For Newsletter</h2>
    <div class="input-field">
        <input type="email" placeholder="Email address..." required>
        <button class="btn">Subscribe</button>
    </div>
</div>

<footer>
    <div class="overlay"></div>
    <div class="footer-content">
        <div class="img-box">
            <img src="img/logo2.png" alt="Logo">
        </div>
        <div class="inner-footer">
            <div class="fcard">
                <h3>About Us</h3>
                <ul>
                    <li><a href="../frontend/about.php">About Us</a></li>
                    <li>Our Difference</li>
                    <li>Community Matters</li>
                    <li>Press</li>
                    <li>Blog</li>
                    <li>Bouqs Video</li>
                </ul>
            </div>
            <div class="fcard">
                <h3>Services</h3>
                <ul>
                    <li>Order</li>
                    <li>Help Center</li>
                    <li>Shipping</li>
                    <li>Terms of Use</li>
                    <li>Account Details</li>
                    <li>My Account</li>
                </ul>
            </div>
            <div class="fcard">
                <h3>Newsletter</h3>
                <p>Subscribe to our newsletter for the latest updates.</p>
                <div class="social-links">
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-behance"></i>
                    <i class="fab fa-youtube"></i>
                    <i class="fab fa-whatsapp"></i>
                </div>
            </div>
        </div>
        <div class="bottom-footer">
            <p>&copy; 2024 ECommerce Store. All rights reserved.</p>
        </div>
    </div>
</footer>
