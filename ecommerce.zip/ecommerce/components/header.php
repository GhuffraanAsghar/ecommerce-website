<header class="header"> 
    <div class="flex">
        <a href="home.php" class="logo">
            <img src="../frontend/img/logo.jpg" alt="Logo">
        </a>
        <nav class="navbar">
            <a href="home.php">Home</a>   
            <a href="view_products.php">Products</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </nav>
        
        <!-- Search Form -->
        <form id="search-form" class="search-form">
            <input type="text" id="search-input" placeholder="Search products..." aria-label="Search">
        </form>
        
        <div class="icons">
            <i class="fas fa-user" id="user-btn"></i>
            <a href="wishlist.php" class="cart-btn">
                <i class="fas fa-heart"></i>
                <sup>0</sup>
            </a>
            <a href="../frontend/cart.php" class="cart-btn">
                <i class="fas fa-shopping-cart"></i>
                <sup>0</sup>
            </a>
        </div>
    </div>

    <i class="fas fa-bars" id="menu-btn" style="font-size: 2rem;"></i>

    <div class="user-box">
        <p>Username: <span><?php echo $_SESSION['user_name']; ?></span></p>
        <p>Email: <span><?php echo $_SESSION['user_email']; ?></span></p>
        <a href="login.php" class="btn">Login</a>
        <a href="register.php" class="btn">Register</a>
        <form method="post">
            <a href="logout.php" class="btn">Logout</a>        
        </form>
    </div>
</header>

<!-- Link to external JavaScript file -->
<script src="../frontend/search.js"></script>
