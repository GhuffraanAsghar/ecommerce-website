<?php
$db_name = 'mysql:host=localhost;dbname=shop_db';
$db_user = 'root';
$db_pass = '';
$conn = new PDO($db_name, $db_user, $db_pass);
function unique_id(){
    $chars = '0123456789abcdefghijklmopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charsLength = strlen($chars);
    $randomString = '';
    for ($i = 0; $i < 20; $i++) {
        $randomString.= $chars[mt_rand(0, $charsLength - 1)];
    }
    return $randomString;   
}
?>