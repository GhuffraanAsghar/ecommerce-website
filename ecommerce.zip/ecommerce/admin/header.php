
<head>
    <script src="https://kit.fontawesome.com/05f313bbaf.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../admin/css/header.css">
</head>
<body>

<header class="header"> 
    <div class="flex">
        <a href="dashboard.php" class="logo">
            <img src="../frontend/img/logo.jpg" alt="Logo">
        </a>
        <nav class="navbar">
            <a href="dashboard.php">dashboard</a>
            <a href="add-products.php">Products</a>
            <a href="order.php">Orders</a>
            <a href="user.php">users</a>

        </nav>
    </div>

    <i class="fas fa-bars" id="menu-btn" style="font-size: 2rem;"></i>

    
    </div>
</header>
<script>
    document.querySelector('.header').style.backgroundColor = 'white';
</script>
</body>
</html>
